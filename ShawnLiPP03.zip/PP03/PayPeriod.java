package PP03;

import java.text.SimpleDateFormat;
import java.util.Date;


public class PayPeriod {
	
	private int pID;
    private Date pStartDate, pEndDate;
	
    public PayPeriod(int pID, Date pStartDate, Date pEndDate) {
		this.pID = pID;
		this.pStartDate = pStartDate;
		this.pEndDate = pEndDate;
	}
    
	public int getpID() {
		return pID;
	}
	public void setpID(int pID) {
		this.pID = pID;
	}
	public Date getpStartDate() {
		return pStartDate;
	}
	public void setpStartDate(Date pStartDate) {
		this.pStartDate = pStartDate;
	}
	public Date getpEndDate() {
		return pEndDate;
	}
	public void setpEndDate(Date pEndDate) {
		this.pEndDate = pEndDate;
	}
	@Override
	public String toString() {
		
		return "\nPayPeriod [pID=" + pID + ", pStartDate=" + DateToStr(pStartDate)+ ", pEndDate=" + DateToStr(pEndDate) + "]";
	}
	
	public static String DateToStr(Date date) { 
		  
		   SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy"); 
		   String str = format.format(date); 
		   return str; 
		} 
    

	
}
