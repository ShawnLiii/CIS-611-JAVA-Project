package PP03;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

public class PayRoll {
	
	private String fileName;
	private PayRecord[] payRecords;
	private PayRecord payRecord;
	private Employee [] employees;
	private Employee employee=null;
	private  double totalNetPay;
	private  double avgNetPay;
	private int countEmp=0;
	private int countPyr=0;
	private Status s = null;
	
	public PayRoll(String fileName, int n){
		
				this.fileName = fileName;
                this.payRecords = new PayRecord[n];
                this.employees=new Employee [n] ;
		
	}
	

public String getFileName() {
		return fileName;
	}


	public void setFileName(String fileName) {
		this.fileName = fileName;
	}


	public PayRecord[] getPayRecords() {
		return payRecords;
	}


	public void setPayRecords(PayRecord[] payRecords) {
		this.payRecords = payRecords;
	}


	public PayRecord getPayRecord() {
		return payRecord;
	}


	public void setPayRecord(PayRecord payRecord) {
		this.payRecord = payRecord;
	}





	public Employee[] getEmployees() {
		return employees;
	}


	public void setEmployees(Employee[] employees) {
		this.employees = employees;
	}


	public Employee getEmployee() {
		return employee;
	}


	public void setEmployee(Employee employee) {
		this.employee = employee;
	}


	public double getTotalNetPay() {
		return totalNetPay;
	}


	public void setTotalNetPay(double totalNetPay) {
		this.totalNetPay = totalNetPay;
	}


	public double getAvgNetPay() {
		return avgNetPay;
	}


	public void setAvgNetPay(double avgNetPay) {
		this.avgNetPay = avgNetPay;
	}


	public int getCountEmp() {
		return countEmp;
	}


	public void setCountEmp(int countEmp) {
		this.countEmp = countEmp;
	}


	public int getCountPyr() {
		return countPyr;
	}


	public void setCountPyr(int countPyr) {
		this.countPyr = countPyr;
	}


public void readFromFile() throws IOException, ParseException{
		
		// read the initial data from PayRoll file to create the full pay records with gross pay, taxes, and net pay, and then store it in PayRecord.txt file
	    String output = "";
		int i=0;
		
		String  pFirstName = null,pLastName = null,status= null,street= null, houseNumber= null,city= null,state= null;
		int     employeeId = 0, rId = 0,numberOfMonths = 0,pId = 0,zipCode = 0;
		Date  pStartDate = null,pEndDate = null;
		double  payHours = 0,payRate = 0,monthlyPay = 0,monthlyIncome = 0;
		// Create a File instance
	    File file = new File(fileName);

	    // Create a Scanner for the file
	    Scanner input = new Scanner(file);


	    // Read data from a file
	    while (input.hasNext()) {	
	    	
	    	 String lineInput=input.nextLine();
	    	 String [] info=lineInput.split(",");
	    	 
	    // put the separated information into different array 
	    	 if(info[0].equals("employee")){
	    	
	    	 employeeId=Integer.parseInt(info[1].trim());	
	    	 pFirstName=info[2].trim();
	    	 pLastName=info[3].trim();
	    	 status=info[4].trim();
	    	 street=info[5].trim();
	    	 houseNumber=info[6].trim();
	    	 city=info[7].trim();
	    	 state=info[8].trim();
	    	 zipCode=Integer.parseInt(info[9].trim());
	    	
	    	 if (status.equals("FULLTIME")) {
		        	s=Status.FullTime;
		        }else if(status.equals("HOURLY")){
		        	s=Status.Hourly;
			} 
	    	 
	    	 employees[countEmp]= createEmployee(employeeId,pFirstName,pLastName,s,street,houseNumber,city,state,zipCode);
	    	 countEmp++;
	    	 
	    	 }else if(info[0].equals("payRecord")) {
	    		
	    		String temp =info[3].substring(info[3].length()-3, info[3].length());	
	    		
	    		if(temp.equals("<m>")) {
	    			rId=Integer.parseInt(info[1].trim());
	    			employeeId=Integer.parseInt(info[2].trim());
	    			monthlyIncome=Double.parseDouble(info[3].trim().substring(0,info[3].length()-4));
	    			numberOfMonths=Integer.parseInt(info[4].trim().substring(0,info[4].length()-4));
	    			pId=Integer.parseInt(info[5].trim());
	    			pStartDate=StrToDate(info[6].trim());
	    			pEndDate=StrToDate(info[7].trim());
	    			payHours=0.0;
	    			payRate=0.0;	
	    		}else if(temp.equals("<h>")) {
	    			rId=Integer.parseInt(info[1].trim());
	    			employeeId=Integer.parseInt(info[2].trim());
	    			payHours=Double.parseDouble(info[3].trim().substring(0,info[3].length()-4));
	    			payRate=Double.parseDouble(info[4].trim().substring(0,info[4].length()-4));
	    			pId=Integer.parseInt(info[5].trim());
	    			pStartDate=StrToDate(info[6].trim());
	    			pEndDate=StrToDate(info[7].trim());
	    			monthlyPay=0.0;
	    			numberOfMonths=0;			
	    		}
	    		
	    		createPayRecord(rId,employees[countPyr],monthlyIncome, numberOfMonths, payHours, payRate, pId, pStartDate, pEndDate);
	    		
	    	}
	    	
	    	 
	    }
	    // Close the file
	    input.close();
	    JOptionPane.showMessageDialog(null, "Completed Read the file");
	} 
   
   
   public void writeToFile(String outputFileName)throws IOException{
		
		// write employees' pay records to the PayRecord.txt file, it should add employee pay record to the current file data
	    File file = new File(outputFileName);
	    // Create a file
		 PrintWriter output = new PrintWriter(file);
	  	// read data from arrays
		 String info=" ";
			for (int i = 0; i < payRecords.length; i++) {
				info += employees[i]+ "\n"+payRecords[i];
			}

			output.print(info);
			output.close();// close the file
	} 
   
	public Employee createEmployee(int employeeId,String pFirstName,String pLastName,Status status,String street,String houseNumber,String city,String state,int zipCode){

		Address address=new Address(street,houseNumber,city,state,zipCode);
		
		 if ( countEmp<employees.length) {
			 
		 	employee = new Employee(pFirstName,pLastName,address,employeeId,s);	
	}else
		
	    JOptionPane.showMessageDialog(null, "The array of employee is full");
		 
		 return employee;
	}
	
 
	public void createPayRecord(int rId, Employee employee, double monthlyIncome, int numberOfMonths, double payHours, double payRate, int pId, Date pStartDate, Date pEndDate){
		
		 PayPeriod period=new PayPeriod (pId,  pStartDate,  pEndDate); 

		// creates a new PayRecord for an Employee object and add it to the payRecords array, you need to pass parameters to this method
		if (countPyr < payRecords.length) {
		 if( employee.getEmpStatus().equals(Status.Hourly)) {
			payRecord =new PayRecord(rId, employee, period, payHours, payRate);
			payRecords[countPyr]=payRecord;
			countPyr++;
		 }else if (employee.getEmpStatus().equals(Status.FullTime)) {
			 payRecord =new PayRecord(rId, employee, period,monthlyIncome,numberOfMonths);
			 payRecords[countPyr]=payRecord;
			 countPyr++;
		  }
		}	
	}

    public  void displayPayRecord( JTextArea textArea){
		
		// it shows all payroll records for all currently added employee and the total net pay and average net pay in the GUI text area
    	// at should append data to text area, it must not overwrite data in the GUI text area
    	String output="";
    	
    	for (int i=0;i<payRecords.length;i++) {
    		
    		if (payRecords[i] != null) {
    		
    			output+=payRecords[i].toString()+"\n";
    		}
		}	
    	
    	textArea.setText(output);
    	
	}

   
    
   public double avgNetPay(){
		
		  	// returns the average of the total net pay of all added employees
	
	   return totalNetPay()/employees.length;
		
	}
   
   public double totalNetPay(){
		
	  	// returns the average of the total net pay of all added employees
	   double sum=0; 
  
	   for(int i=0;i<employees.length;i++) {
	  
	   sum+=payRecords[i].netPay();
	   
  }
 
	   return sum;
	
}
   public static Date StrToDate(String str) { 
	   
	   SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy"); 
	   Date date = null; 
	  
	   try { 
	    date = format.parse(str); 
	   } catch (ParseException e) { 
	    e.printStackTrace(); 
	   } 
	   return date; 
	}  	

}
