package PP03;

public enum Status {
	
	FullTime, Hourly

}
