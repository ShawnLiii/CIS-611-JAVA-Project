//*********************************************************************
//*                                                                   *
//*    CIS611             Spring Semester 2019              Shawn Li  *
//*                                                                   *
//*                    Programming Assignment PA0401                  *
//*                                                                   *
//*                         Class Description                         *
//*                                                                   *
//*                                                                   *
//*                             3/1/2019                              *
//*                                                                   *
//*                Saved in: CheckPassword.java               		  *
//*                                                                   *
//*********************************************************************
import java.util.regex.*;
import javax.swing.*;
public class CheckPassword {

	public static void main(String[] args) throws Exception{
		
		boolean reInput=true;
		
		while(reInput){
		String password=JOptionPane.showInputDialog(null,"Please input your password based on three rules:\nThe password must contains at least eight characters"
				+ "\n\tThe password must contains at least one special characters, e.g., %, &, #"
				+ "\n\tThe password must contains at least two digits");
		
			if (isValidPassword(password)) {
				JOptionPane.showMessageDialog(null,"Valid password");
				break;
			}else {
				JOptionPane.showMessageDialog(null,"Invalid password");
				int ifInput=JOptionPane.showConfirmDialog(null,"Do you want to re-input your password?");
				
				if (ifInput==0) {
					
					reInput=true;
				}
				if (ifInput==1||ifInput==2||ifInput==-1) {
					
					System.exit(0);
				}
			}
		}
		
	}
	
	// Check if user input is a valid password
	
	public static boolean isValidPassword(String password) {
		
		boolean verifyPassword=false;
		 // Check if the password contains at least eight characters, 
		//	and at least one special characters from %, &, # 
		//	and contains at least two digits
		if (password.length()>=8&&checkSpecialCharacter(password)&&checkTwoDigits(password)) 
			verifyPassword=true;
		
			return verifyPassword;
															}
	// Check if the password contains at least one special characters from %, &, #
	public static boolean checkSpecialCharacter(String password) {
		
		String regEx = "[#&%]|\n|\r|\t";
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(password);
        return m.find();		
		
	}
	//Check if the password contain at least two digits
	public static boolean checkTwoDigits(String password) {
		
		Matcher match = Pattern.compile("\\d").matcher(password);
        int count = 0;
        while (match.find())
            count++;
        return count >= 2;
	}
	
   
}