//*********************************************************************
//*                                                                   *
//*    CIS611             Spring Semester 2019              Shawn Li  *
//*                                                                   *
//*                    Programming Assignment PA0402                  *
//*                                                                   *
//*                         Class Description                         *
//*                                                                   *
//*                                                                   *
//*                             3/1/2019                              *
//*                                                                   *
//*                Saved in: Product.java               			  *
//*                                                                   *
//*********************************************************************
import java.io.*;
import java.util.*;
import javax.swing.*;

public class Product {
	
	 static class Sort {
		
		public static void selectionSort(String pName[],double pPrice[]) {
			String output = "";
			int i=0;
			
			for ( i = 0; i < pPrice.length - 1; i++) {
		        // Find the minimum in the array[i..array.length-1]
		        double currentMin = pPrice[i];
		        String currentMinName=pName[i];
		        int currentMinIndex = i;

		        for (int j = i + 1; j < pPrice.length; j++) {
		          if (currentMin > pPrice[j]) {
		            currentMin = pPrice[j];
		            currentMinName = pName[j];
		            currentMinIndex = j;
		          }
		        }

		        // Swap list[i] with list[currentMinIndex] if necessary;
		        if (currentMinIndex != i) {
		        	pPrice[currentMinIndex] = pPrice[i];
		        	pPrice[i] = currentMin;
		        	
		        	pName[currentMinIndex] = pName[i];
		        	pName[i] = currentMinName;
		        }
		      }
				i=0;
		      while (i<pPrice.length){
		      	output+= pName[i]+"  "+pPrice[i] + "  \n";
		      	i++;
		      }

		      JOptionPane.showMessageDialog(null,"Array after sorting:\n"+ output);
		      JOptionPane.showMessageDialog(null, "Completed sort the file");
		    }
	}
	
	public static void main(String[] args) throws IOException{
		
		String [] pName=new String [50];
		double [] pPrice=new double[50];
		
		readFromFile("products.txt",pName,pPrice);
		sortArray(pName,pPrice);
		writeToFile(pName,pPrice);
		
	}
	
	public static void readFromFile(String filename, String [] pName, double [] pPrice) throws IOException {
		String output = "";
		int i=0;
		// Create a File instance
	    File file = new File(filename);

	    // Create a Scanner for the file
	    Scanner input = new Scanner(file);
	    //Scanner input = new Scanner(file);

	    int count=0;
	    // Read data from a file
	    while (input.hasNext()) {	
	    	
	    	 String lineInput=input.nextLine();
	    	 String [] info=lineInput.split(",");
	    // put the separated information into pName an pPrice array 
	    	// JOptionPane.showMessageDialog(null,info); 
	    	 
		    pName[count]=info[0];
		   	pPrice[count]=Double.parseDouble(info[1]);
	    	 
	    	 count++;
	    }
	    	
	      while (i<pPrice.length){
	      	output+= pName[i]+"  "+pPrice[i] + " \n";
	      	i++;
	      }

	      JOptionPane.showMessageDialog(null,"Array before sorting:\n"+ output);
	    
	
	    // Close the file
	    input.close();
	    JOptionPane.showMessageDialog(null, "Completed Read the file");
	}
	
	
	public static void sortArray(String [] pName,double [] pPrice) {
		
		Sort.selectionSort(pName, pPrice);
		
	}
	
	public static void writeToFile( String [] pName, double [] pPrice ) throws IOException{
		
		File file = new File("sortedProducts.txt");
	    // Create a file
		 PrintWriter output = new PrintWriter(file);
	  	// read data from arrays
		 String message=" ";
	  // Program output after sorting
	  for(int i=0;i<pPrice.length;i++) {
		  message+=pName[i]+"  "+pPrice[i] + " \n";
	  }
	  //write formatted output to the file
	  output.write(message);
	    // Close the file
	  JOptionPane.showMessageDialog(null,"Complete write the file");
	    output.close();

	}

}
