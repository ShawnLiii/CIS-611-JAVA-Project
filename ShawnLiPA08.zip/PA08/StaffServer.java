package PA08;

// add the class template 

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketImpl;
import java.applet.*;
import javax.swing.*;

import java.sql.*;
import javax.swing.border.*;
public class StaffServer {
 
 
  static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
  // URL??
  private static final String DB_URL = "jdbc:mysql://BUSCISMYSQL01:3306/lizijiandb";
private static final String USER = "lizijian";
private static final String PASS = "c611c!18256";
private ResultSet resultSet = null,resultSet2=null,resultSet3=null;
  private Connection connect = null;
  private Statement stmt,stmt2,stmt3;
  private int port;
  private Message msg;
  private final int INSERT_OP = 0;
  private  final int VIEW_OP = 1;
  private  final int UPDATE_OP = 2;
  private  final int DELETE_OP = 3;
  private ServerSocket serverSocket;
  private PreparedStatement preparedStatement = null;
  public StaffServer (int port) throws ClassNotFoundException, IOException, SQLException{
	  
	  this.port = port;
	  initializeDB(port);
  }

  
  private void initializeDB(int ListeningPort) throws IOException, ClassNotFoundException, SQLException {
    
	  this.serverSocket = new ServerSocket(ListeningPort);
		
	  //  load the MySQL driver
	     Class.forName(JDBC_DRIVER);
	     System.out.println("Driver loaded");
	 	
	  // Connect to your database using your credentials
	     connect = DriverManager.getConnection(DB_URL,USER,PASS);
	     System.out.println("Database connected!");

	      // Create a statement object
	     stmt = connect.createStatement();
	     
	     while (true) {
	         //  loops for ever waiting for the client connection requests
	         Socket socket = serverSocket.accept();
	         
	         
	         // create a thread for each client connection request using Runnable class HandleAClient 
	         HandleAClient task = new HandleAClient(socket);
	         new Thread(task).start();
    }
  }

  /**View record by ID
 * @throws SQLException */
  private void view(Message msg) throws SQLException {
	    int mPhoneNo, hPhoneNo;
		String lastName, firstName, address, city, state, mPhoneCarrier, hPhoneCarrier;
		char mi;
		String output = null;
   // Build a SQL SELECT statement
	    stmt = connect.createStatement();
		resultSet = stmt.executeQuery("select * from staff where id = "+msg.getId()+";");

		if(!resultSet.next()){
			msg.setId(0);
			msg.setMsg("Record not found.");
			return;
		}
		
		lastName = resultSet.getString(2);
		firstName = resultSet.getString(3);
		mi = resultSet.getString(4).charAt(0);
		address = resultSet.getString(5);
		city = resultSet.getString(6);
		state = resultSet.getString(7);
		mPhoneNo = Integer.parseInt(resultSet.getString(8));
		hPhoneNo = Integer.parseInt(resultSet.getString(9));
		resultSet = stmt.executeQuery("select * from telephone where phone = "+mPhoneNo+";");
		resultSet.next();
		mPhoneCarrier = resultSet.getString(2);
		resultSet = stmt.executeQuery("select * from telephone where phone = "+hPhoneNo+";");
		resultSet.next();
		hPhoneCarrier = resultSet.getString(2);
		
		msg.setLastName(lastName);
		msg.setFirstFName(firstName);
		msg.setMi(mi);
		msg.setAddress(address);
		msg.setCity(city);
		msg.setState(state);
		msg.setmPhoneNo(mPhoneNo);
		msg.setmPhoneCarrier(mPhoneCarrier);
		msg.sethPhoneNo(hPhoneNo);
		msg.sethPhoneCarrier(hPhoneCarrier);

  }

  
  /**Insert a new record
 * @throws SQLException */
  private void insert(Message msg) throws SQLException {
    // Build a SQL INSERT statement
	    stmt = connect.createStatement();
	    stmt2 = connect.createStatement();
	    stmt3 = connect.createStatement();
	    
		resultSet = stmt.executeQuery("select * from Staff Where id = " + msg.getId() + ";");
		resultSet2 = stmt2.executeQuery("select * from Staff Where mobilephone = " + msg.getmPhoneNo() + ";");
		resultSet3 = stmt3.executeQuery("select * from Staff Where homephone = " + msg.gethPhoneNo() + ";");
		 
		if (resultSet.next()){ 
			msg.setId(0);
			msg.setMsg("ID already exists in the database. Please try agian");
			return;
		}
	     else if (resultSet2.next()||resultSet3.next()){
	    	 	msg.setId(0);
				msg.setMsg("Phone number already exists in the database. Please try agian");
				return;
				}
	     else{

			      preparedStatement = connect
				          .prepareStatement("insert into  telephone values (?, ?)");
			      preparedStatement.setInt(1, msg.gethPhoneNo());
			      preparedStatement.setString(2, msg.gethPhoneCarrier());
			      preparedStatement.execute();
			      
			      preparedStatement = connect
				          .prepareStatement("insert into  telephone values (?, ?)");
			      preparedStatement.setInt(1, msg.getmPhoneNo());
			      preparedStatement.setString(2, msg.getmPhoneCarrier());
			      preparedStatement.execute();
			      
			      preparedStatement = connect
				          .prepareStatement("insert into  staff values (?, ?, ?, ?, ?, ?, ?, ?, ?)");
					  preparedStatement.setInt(1, msg.getId());
				      preparedStatement.setString(2, msg.getLastName());
				      preparedStatement.setString(3, msg.getFirstFName());
				      preparedStatement.setString(4, String.valueOf(msg.getMi()));
				      preparedStatement.setString(5, msg.getAddress());
				      preparedStatement.setString(6, msg.getCity());
				      preparedStatement.setString(7, msg.getState());
				      preparedStatement.setInt(8, msg.getmPhoneNo());
				      preparedStatement.setInt(9, msg.gethPhoneNo());
				      
				      preparedStatement.execute();
				      System.out.println("Insert Sucssess");
					}
   }

  /**Update a record
 * @throws SQLException */
  private void update(Message msg) throws SQLException {
  // Build a SQL UPDATE statement
	  stmt = connect.createStatement();
		
		resultSet = stmt.executeQuery("select * from Staff Where id = " + msg.getId() + ";");
		 
		if (!resultSet.next()){ 
			msg.setId(0);
			msg.setMsg("ID does not exists in the database. Please try agian");
			return;
		}else{

					 preparedStatement = connect
					          .prepareStatement("update staff set address = '"+ msg.getAddress() + 
					        		  "' where id = "+ msg.getId() + ";");
					      preparedStatement.execute();
				}	   
  }

  /**Clear text fields
 * @throws SQLException */
  private void delete(Message msg) throws SQLException {
	// Build a SQL DELETE statement
	  stmt = connect.createStatement();
		resultSet = stmt.executeQuery("select * from Staff Where id = " + msg.getId() + ";");
				 
		if (!resultSet.next()){
			msg.setId(0);
			System.out.println("ID does not exists in the database. Please try agian");
		}
		else{
			int mPhoneNo = Integer.parseInt(resultSet.getString(8));
			int hPhoneNo = Integer.parseInt(resultSet.getString(9));
			
			preparedStatement = connect
			          .prepareStatement("delete from staff where id=" + msg.getId());
			      preparedStatement.execute();
		      preparedStatement = connect
			          .prepareStatement("delete from telephone where phone=" + mPhoneNo);
				      preparedStatement.execute();
		      preparedStatement = connect
			          .prepareStatement("delete from telephone where phone=" + hPhoneNo);
					      preparedStatement.execute();
		}
  }
  
  public void closeAll() throws IOException, SQLException{
		 
	    resultSet.close();
	    stmt.close();
	    connect.close();
		 System.exit(0); 
	   }

    // inner Runnable class handle a client connection
	class HandleAClient implements Runnable {
	    private Socket socket; // A connected socket

	    /** Construct a thread */
	    public HandleAClient(Socket socket) {
	      this.socket = socket;
	    }

	    /** Run a thread */
	    public void run() {
	    	  try {
	    	// write the code to call a proper method to process the client request
	        // Create data input and output streams
	        ObjectInputStream inputFromClient = new ObjectInputStream(
	          socket.getInputStream());
	        ObjectOutputStream outputToClient = new ObjectOutputStream(
	          socket.getOutputStream());

	        // Continuously serve the client
	        while (true) {
	        	Message message = null;	
	    		message = (Message )inputFromClient.readObject();
	    		
	    		
	            switch (message.getType()) { 
	    		
	            case INSERT_OP: insert(message);
		        	break; 
		        
	            case VIEW_OP: view(message);
	            	break;
   
	            case UPDATE_OP: update(message);
                      break; 

	            case DELETE_OP: delete(message);
                       break; 
	    		 }
	    			
	            outputToClient.writeObject(message);; 
	    	  }
	        
	       
	      }
	      catch(IOException e) {
	        System.err.println(e);
	      } catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    	
	    }
	   }// end of class Runnable 
  
  public static void main(String[] args) throws ClassNotFoundException, IOException, SQLException {
    StaffServer server = new StaffServer(8000);
    
  }
}
