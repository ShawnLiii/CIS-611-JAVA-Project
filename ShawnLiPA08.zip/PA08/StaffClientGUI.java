package PA08;

//add the class template

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.*;

class StaffClientGUI extends JFrame implements ActionListener{
	


	static boolean gotCorrect,isInsertClicked=false;
	private String hostname;
	private int port;
	private Message msg;
	private final int INSERT_OP = 0;
	private  final int VIEW_OP = 1;
	private  final int UPDATE_OP = 2;
	private  final int DELETE_OP = 3;
	private Socket clientSocket;
	 ObjectOutputStream clientOutputStream;
	 ObjectInputStream clientInputStream;
	private JButton viewBtn,insertBtn,updateBtn,deleteBtn,clearBtn,closeBtn;
	private JLabel staffInforLabel,idLabel,lastNameLabel,firstNameLabel,middleNameLabel,addressLabel,cityLabel,stateLabel,mobilePhoneNumberLabel,mobilePhoneCarrierLabel,homePhoneNumberLabel,homePhoneCarrierLabel,databaseStatusLabel;
	private JTextField idTxt,lastNameTxt,firstNameTxt,middleNameTxt,addressTxt,cityTxt,mobilePhoneNumberTxt,homePhoneNumberTxt,mobilePhoneCarrierTxt,homePhoneCarrierTxt;
	private JComboBox stateList;
// declare UI component objects
	
public StaffClientGUI(String hostname, int port) throws IOException {
	
	this.port = port;
	this.hostname = hostname;
	
	// Create a connection with the StaffServer server on port number 8000	
	connect(hostname,port);
	// call these two methods to create user GUI
	initComponenet();
	doTheLayout();
	insertBtn.addActionListener(this);
	viewBtn.addActionListener(this);
	updateBtn.addActionListener(this);
	deleteBtn.addActionListener(this);
	clearBtn.addActionListener(this);
	closeBtn.addActionListener(this);
	
}

public void connect(String hostAddress,int  connectingPort) throws IOException{
	
	clientSocket= new Socket(hostname,port);
    clientOutputStream = new ObjectOutputStream(clientSocket.getOutputStream());
    clientInputStream = new ObjectInputStream(clientSocket.getInputStream());
}

public void sendMessage() throws IOException, ClassNotFoundException {	
	
	clientOutputStream.writeObject(msg);
   	receivingMessage();
	
	}

private void receivingMessage() throws IOException, ClassNotFoundException {
	
	msg = (Message)clientInputStream.readObject();
	
	switch(msg.getType()){		
	
	case INSERT_OP:
		
		if(msg.getId()!=0)
			JOptionPane.showMessageDialog(null,"Insert succeed!");
		
		else
			JOptionPane.showMessageDialog(null,"Insert fail!\n" + msg.getMsg());
		
	    break;
	    
	case VIEW_OP:
		
		if(msg.getId()!=0) {
			
			
		String output="ID: "+String.valueOf(msg.getId())+"\n"+"Last Name: "+msg.getLastName()+"     First Name: "+msg.getFirstFName()+"     Middle Name: "+String.valueOf(msg.getMi())+"\n"+
							"Address: "+msg.getAddress()+"     City: "+msg.getCity()+"     State: "+msg.getState()+"\n"+
							"Mobile Phone Number: "+String.valueOf(msg.getmPhoneNo())+"     Mobile Phone Carrier: "+msg.getmPhoneCarrier()+"\n"+
							"Home Phone Number: "+String.valueOf(msg.gethPhoneNo())+"     Home Phone Carrier: "+msg.gethPhoneCarrier();
		JOptionPane.showMessageDialog(null,output);
		
			idTxt.setText(String.valueOf(msg.getId()));
			lastNameTxt.setText(msg.getLastName());
			firstNameTxt.setText(msg.getFirstFName());
			middleNameTxt.setText(String.valueOf(msg.getMi()));
			addressTxt.setText(msg.getAddress());
			cityTxt.setText(msg.getCity());
			mobilePhoneNumberTxt.setText(String.valueOf(msg.getmPhoneNo()));
			mobilePhoneCarrierTxt.setText(msg.getmPhoneCarrier());
			homePhoneNumberTxt.setText(String.valueOf(msg.gethPhoneNo()));
			homePhoneCarrierTxt.setText(msg.gethPhoneCarrier());
			stateList.setSelectedItem(msg.getState());
			
		}else
			
			JOptionPane.showMessageDialog(null,msg.getMsg());
		
		break;  
		
	case UPDATE_OP:
		
		if(msg.getId()!=0)
			JOptionPane.showMessageDialog(null,"Update succeed!");
		else
			JOptionPane.showMessageDialog(null,"Update fail!\n" + msg.getMsg());
	    break;
	    
	case DELETE_OP:
		
		if(msg.getId()!=0)
			JOptionPane.showMessageDialog(null,"Delete succeed!");
		else
			JOptionPane.showMessageDialog(null,"Delete fail!" + msg.getMsg());
	    break;
	    
	}
}

private void initComponenet(){
	// Initialize the GUI components
	//labels
	staffInforLabel=new JLabel("Staff Information");
	staffInforLabel.setForeground(Color.BLUE);
	idLabel=new JLabel(" ID ");
	lastNameLabel=new JLabel(" Last Name ");
	firstNameLabel=new JLabel(" First Name ");
	middleNameLabel=new JLabel(" Middle Name ");
	addressLabel=new JLabel(" Address ");
	cityLabel=new JLabel(" City ");
	stateLabel=new JLabel(" State");
	mobilePhoneNumberLabel=new JLabel(" Mobile Phone Number ");
	mobilePhoneCarrierLabel=new JLabel(" Mobile Phone Carrier");
	homePhoneNumberLabel=new JLabel(" Home Phone Number ");
	homePhoneCarrierLabel=new JLabel(" Home Phone Carrier");
	databaseStatusLabel=new JLabel(" Database Connected");
	databaseStatusLabel.setForeground(Color.BLUE);
	//text field
	idTxt=new JTextField(10);
	lastNameTxt=new JTextField(15);
	firstNameTxt=new JTextField(15);
	middleNameTxt=new JTextField(5);
	addressTxt=new JTextField(20);
	cityTxt=new JTextField(10);
	mobilePhoneNumberTxt=new JTextField(15);
	homePhoneNumberTxt=new JTextField(15);
	mobilePhoneCarrierTxt=new JTextField(15);
	homePhoneCarrierTxt=new JTextField(15);
	//buttons
	viewBtn=new JButton(" View ");
	insertBtn=new JButton(" Insert ");
	updateBtn=new JButton(" Update ");
	deleteBtn=new JButton(" Delete ");
	clearBtn=new JButton(" Clear ");
	closeBtn=new JButton(" Close ");	
	//Combo Box
	
	   stateList=new JComboBox();
	   stateList.addItem("Alabama");stateList.addItem("Alaska");stateList.addItem("Arizona");stateList.addItem("Arkansas");stateList.addItem("California");
	   stateList.addItem("Colorado");stateList.addItem("Connecticut");stateList.addItem("Delaware");stateList.addItem("Florida");stateList.addItem("Georgia");
	   stateList.addItem("Hawaii");stateList.addItem("Idaho");stateList.addItem("Illinois");stateList.addItem("Indiana");stateList.addItem("Iowa");
	   stateList.addItem("Kansas");stateList.addItem("Kentucky");stateList.addItem("Louisiana");stateList.addItem("Maine");stateList.addItem("Maryland");
	   stateList.addItem("Massachusetts");stateList.addItem("Michigan");stateList.addItem("Minnesota");stateList.addItem("Mississippi");stateList.addItem("Missouri");
	   stateList.addItem("Montana");stateList.addItem("Nebraska");stateList.addItem("Nevada");stateList.addItem("New hampshire");stateList.addItem("New jersey");
	   stateList.addItem("New mexico");stateList.addItem("New York");stateList.addItem("North Carolina");stateList.addItem("North Dakota");stateList.addItem("Ohio");
	   stateList.addItem("Oklahoma");stateList.addItem("Oregon");stateList.addItem("Pennsylvania");stateList.addItem("Rhode island");stateList.addItem("South carolina");
	   stateList.addItem("South dakota");stateList.addItem("Tennessee");stateList.addItem("Texas");stateList.addItem("Utah");stateList.addItem("Vermont");
	   stateList.addItem("Virginia");stateList.addItem("Washington");stateList.addItem("West Virginia");stateList.addItem("Wisconsin");stateList.addItem("Wyoming");
}

private void doTheLayout(){
	// Arrange the UI components into GUI window
	// Declare panel
	JPanel client=new JPanel();
	JPanel infor_top=new JPanel();
	JPanel infor_center=new JPanel();
	JPanel infor_buttom=new JPanel();
	JPanel buttonLayer=new JPanel();
	JPanel databaseStatusLayer=new JPanel();
	JPanel idLayer=new JPanel();
	JPanel personInforLayer=new JPanel();
	JPanel phoneInforLayer=new JPanel();
	JPanel personLayer=new JPanel();
	JPanel addressLayer=new JPanel();
	JPanel mobilePhoneLayer=new JPanel();
	JPanel homePhoneLayer=new JPanel();
	JPanel infoLabelLayer=new JPanel();
	
	//set the whole client GUI as borderLayout
	this.setLayout(new BorderLayout());
	this.add(infor_top,BorderLayout.NORTH);
	this.add(infor_center,BorderLayout.CENTER); 
	this.add(infor_buttom,BorderLayout.SOUTH);
	
	// add components to infor_top layer
	infor_top.setLayout(new GridLayout(2,1));
	infor_top.add(infoLabelLayer);
	infor_top.add(idLayer);
	
	infoLabelLayer.setLayout(new FlowLayout(FlowLayout.LEFT));
	infoLabelLayer.add(staffInforLabel);
	//add components to idLayer
	idLayer.setLayout(new FlowLayout(FlowLayout.LEFT));
	idLayer.add(idLabel);idLayer.add(idTxt);
	
	// set infor_center layer as borderLayout
	infor_center.setLayout(new GridLayout(2,1));
	infor_center.add(personInforLayer);
	infor_center.add(phoneInforLayer);
	//set personInforLayer to GridLayout
	personInforLayer.setLayout(new GridLayout(2,1));
	personInforLayer.add(personLayer);
	personInforLayer.add(addressLayer);
	//add components to personInforLayer
	personLayer.setLayout(new FlowLayout(FlowLayout.LEFT));
	personLayer.add(lastNameLabel);personLayer.add(lastNameTxt);personLayer.add(firstNameLabel);personLayer.add(firstNameTxt);personLayer.add(middleNameLabel);personLayer.add(middleNameTxt);
	addressLayer.setLayout(new FlowLayout(FlowLayout.LEFT));
	addressLayer.add(addressLabel);addressLayer.add(addressTxt);addressLayer.add(cityLabel);addressLayer.add(cityTxt);addressLayer.add(stateLabel);addressLayer.add(stateList);
	
	//set phoneInforLayer to GridLayout
	phoneInforLayer.setLayout(new GridLayout(2,1));
	//add components to phoneInforLayer
	phoneInforLayer.add(mobilePhoneLayer);
	mobilePhoneLayer.setLayout(new FlowLayout(FlowLayout.LEFT));
	mobilePhoneLayer.add(mobilePhoneNumberLabel);mobilePhoneLayer.add(mobilePhoneNumberTxt);mobilePhoneLayer.add(mobilePhoneCarrierLabel);mobilePhoneLayer.add(mobilePhoneCarrierTxt);
	phoneInforLayer.add(homePhoneLayer);
	homePhoneLayer.setLayout(new FlowLayout(FlowLayout.LEFT));
	homePhoneLayer.add(homePhoneNumberLabel);homePhoneLayer.add(homePhoneNumberTxt);homePhoneLayer.add(homePhoneCarrierLabel);homePhoneLayer.add(homePhoneCarrierTxt);

	//set the infor_buttom layer as GridLayout
	infor_buttom.setLayout(new GridLayout(2,1));
	// add components to infor_buttom layer
	infor_buttom.add(buttonLayer);
	infor_buttom.add(databaseStatusLayer);
	buttonLayer.setLayout(new FlowLayout(FlowLayout.CENTER));
	buttonLayer.add(viewBtn);buttonLayer.add(insertBtn);buttonLayer.add(updateBtn);buttonLayer.add(deleteBtn);buttonLayer.add(clearBtn);buttonLayer.add(closeBtn);
	databaseStatusLayer.setLayout(new FlowLayout(FlowLayout.LEFT));
	databaseStatusLayer.add(databaseStatusLabel);

	
}	
	
 
@Override
public void actionPerformed(ActionEvent e) {
	
	if(e.getSource()==viewBtn)
		try {
			viewButtonClicked();
		} catch (ClassNotFoundException | IOException e3) {
			// TODO Auto-generated catch block
			e3.printStackTrace();
		}
	else if(e.getSource()==insertBtn)
		try {
			insertButtonClicked();
		} catch (ClassNotFoundException | IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
	else if (e.getSource()==updateBtn)
		try {
			updateButtonClicked();
		} catch (ClassNotFoundException | IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
	else if (e.getSource()==deleteBtn)
		deleteButtonClicked();
	else if (e.getSource()==clearBtn)
	    clearButtonClicked();
	else if (e.getSource()==closeBtn)
		try {
			closeButtonClicked();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	
	
}

private void insertButtonClicked() throws ClassNotFoundException, IOException{
	  
	  // handle insert button clicked event 
	int id = 0,mPhoneNo = 0, hPhoneNo = 0;
	String lastName = null,firstName = null,address = null,city = null, state = null,mPhoneCarrier = null,hPhoneCarrier = null;
	char mi = 0;
	
	//validation
	if(idTxt.getText().isEmpty()){
		JOptionPane.showMessageDialog(idTxt,"Please input ID");
		idTxt.setText("");
		return;
	}else
		try {
			id=Integer.parseInt(idTxt.getText().trim());
		}catch (Exception ex) {
			JOptionPane.showMessageDialog(null,"Invalid ID number");	
			idTxt.setText("");
			return;
		}

	//input last name
	if(lastNameTxt.getText().isEmpty()){
		JOptionPane.showMessageDialog(lastNameTxt,"Please input Last Name");
		lastNameTxt.setText("");
		return;
	}else
		lastName=lastNameTxt.getText().trim();	
	//input middle name
		if(middleNameTxt.getText().isEmpty()){
			JOptionPane.showMessageDialog(middleNameTxt,"Please input middle Name");
			middleNameTxt.setText("");
			return;
		}else if(middleNameTxt.getText().length()>1) {
			JOptionPane.showMessageDialog(middleNameTxt,"The length of Middle Name should be only 1 character");
		}else
		mi=middleNameTxt.getText().charAt(0);	
	//input first name
	if(firstNameTxt.getText().isEmpty()){
		JOptionPane.showMessageDialog(firstNameTxt,"Please input First Name");
		firstNameTxt.setText("");
		return;
	}else
		firstName=firstNameTxt.getText().trim();

	//input address
	if(addressTxt.getText().isEmpty()){
		JOptionPane.showMessageDialog(addressTxt,"Please input Address");
		addressTxt.setText("");
		return;
	}else
		address=addressTxt.getText();
	//input city
	if(cityTxt.getText().isEmpty()){
		JOptionPane.showMessageDialog(cityTxt,"Please input City");
		cityTxt.setText("");
		return;
	}else
		city=cityTxt.getText();
	//select state
	state=(String)stateList.getSelectedItem();
	//mobile phone number
	if(mobilePhoneNumberTxt.getText().isEmpty()){
		JOptionPane.showMessageDialog(mobilePhoneNumberTxt,"Please input Mobile Phone Number");
		mobilePhoneNumberTxt.setText("");
		return;
	}else
		try {
			mPhoneNo=Integer.parseInt(mobilePhoneNumberTxt.getText().trim());
		}catch (Exception ex) {
			JOptionPane.showMessageDialog(null,"Invalid Mobile Phone Number");	
			mobilePhoneNumberTxt.setText("");
			return;
		}
	// mobile phone carrier
	
	if(mobilePhoneCarrierTxt.getText().isEmpty()){
		JOptionPane.showMessageDialog(mobilePhoneCarrierTxt,"Please input mobile Phone Carrier");
		mobilePhoneCarrierTxt.setText("");
		return;
	}else
		mPhoneCarrier=mobilePhoneCarrierTxt.getText();
	
	//home phone number
	if(homePhoneNumberTxt.getText().isEmpty()){
		JOptionPane.showMessageDialog(homePhoneNumberTxt,"Please input Home Phone Number");
		homePhoneNumberTxt.setText("");
		return;
	}else
		try {
			hPhoneNo=Integer.parseInt(homePhoneNumberTxt.getText().trim());
		}catch (Exception ex) {
			JOptionPane.showMessageDialog(null,"Invalid Home Phone Number");	
			homePhoneNumberTxt.setText("");
			return;
		}
	// home phone carrier
	if(homePhoneCarrierTxt.getText().isEmpty()){
		JOptionPane.showMessageDialog(homePhoneCarrierTxt,"Please input Home Phone Carrier");
		homePhoneCarrierTxt.setText("");
		return;
	}else
		hPhoneCarrier=homePhoneCarrierTxt.getText();
	
	
	//	sendMessage
    msg = new Message(id,lastName,firstName,mi,address,city, state,
		mPhoneNo, hPhoneNo, mPhoneCarrier,hPhoneCarrier,INSERT_OP);

    sendMessage();
	
}

private void viewButtonClicked() throws ClassNotFoundException, IOException {
	  
	  // handle view button clicked event
	// input id to check the Last name,First name, Middle Name, Address, City, Mobile Phone Number, Home Phone Number, Mobile Phone Carrier, and the Home Phone Carrier values for that staff ID
	   int id = 0;
	  
		if(idTxt.getText().isEmpty()){
			JOptionPane.showMessageDialog(idTxt,"ID value does not exist in the database");
			idTxt.setText("");
			return;
		}else 
			try {
				id=Integer.parseInt(idTxt.getText().trim());
			}catch (Exception ex) {
				JOptionPane.showMessageDialog(null,"Invalid ID number");	
				idTxt.setText("");
				return;
			}
		
		
		msg = new Message(id);
		msg.setType(VIEW_OP);
		sendMessage();
		
		
		
  }




private void updateButtonClicked() throws ClassNotFoundException, IOException{
	
	int id=0;
	String address;
	// handle update button clicked event

		
		if(idTxt.getText().isEmpty()){
			JOptionPane.showMessageDialog(idTxt,"Please input ID");
			idTxt.setText("");
			return;
		}else
			try {
				id=Integer.parseInt(idTxt.getText().trim());
			}catch (Exception ex) {
				JOptionPane.showMessageDialog(null,"Invalid ID number");	
				idTxt.setText("");
				return;
			}
		
		
		//input address
		if(addressTxt.getText().isEmpty()){
			JOptionPane.showMessageDialog(addressTxt,"Please input Address");
			addressTxt.setText("");
			return;
		}else
			address=addressTxt.getText();
		
		
		// update	
		msg = new Message(id);
		msg.setType(UPDATE_OP);
		msg.setAddress(address);
		sendMessage();


  }

private void deleteButtonClicked(){
	int id=0; 
	// handle delete button clicked event

		
		if(idTxt.getText().isEmpty()){
			JOptionPane.showMessageDialog(idTxt,"ID value does not exist in the database");
			idTxt.setText("");
			return;
		}else 
			try {
				id=Integer.parseInt(idTxt.getText().trim());
				if(id==99999) {
					JOptionPane.showMessageDialog(idTxt,"ID value does not exist in the database");	
				}else {
					msg = new Message(id);
					msg.setType(DELETE_OP);
					sendMessage();	
				}
			}catch (Exception ex) {
				JOptionPane.showMessageDialog(null,"Invalid ID number");	
				idTxt.setText("");
				return;
			}

	
  }


  
  
  void clearButtonClicked(){
	  
	// handle clear button clicked event
	 idTxt.setText(""); 
	 lastNameTxt.setText("");
	 firstNameTxt.setText(""); 
	 middleNameTxt.setText("");
	 addressTxt.setText("");
	 cityTxt.setText("");
	 mobilePhoneNumberTxt.setText("");
	 mobilePhoneCarrierTxt.setText("");
	 homePhoneNumberTxt.setText("");
	 homePhoneCarrierTxt.setText("");
  }
  

  void closeButtonClicked() throws IOException{
	  
	// handle close button clicked event
	    clientSocket.close();
		clientOutputStream.close();
		clientInputStream.close();
		System.exit(0);
  }
  
  /**Main method
 * @throws IOException */
  public static void main(String[] args) throws IOException {
	 int port = 8000;
	 String hostname=" ";
	 StaffClientGUI frame = null;
	 try {
	 hostname=JOptionPane.showInputDialog(null," Enter the host name");  
	  //Create a new GUI
	   frame = new StaffClientGUI(hostname,port);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Cannot conected to Server. Please try agian");
	        System.exit(0);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Cannot conected to Server. Please try agian");
	        System.exit(0);
		}

	   //Set GUI frame settings
	   frame.setTitle(" Staff Client GUI"); 
	   frame.pack();
	   frame.setResizable(false);
	   frame.setLocationRelativeTo(null);
	   frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	   frame.setVisible(true);
  }
}