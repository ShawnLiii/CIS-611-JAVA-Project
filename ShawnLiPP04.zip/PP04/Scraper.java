package PP04;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Scraper {
	
		private String url;
		private Pattern pattern;
		private Matcher matcher;
		private Regex[] regex;
		private int count = 0;
		// constructor
		public Scraper(String url) {		
			this.url=url;
		}
		
		public void parseData() throws IOException {
				String URLString =this.url;
				 // create a url object
				URL url = new URL(URLString);
				Scanner input = new Scanner(url.openStream());
				//creat pattern
				Pattern pattern=Pattern.compile("(<td class=\"tbdy\">)(.*?)(</td>[\\s]*)(<td class=\"tbdy\">)(.*?)(</td>[\\s]*)"
						+ "(<td><a href=\".*?>)(.*?)(</a></td>[\\s]*)(<td class=\"tbdy\">)(.*?)(</td>[\\s]*)"
						+ "(<td class=\"ra\">[\\s]+TCKL[\\s]+</td>[\\s]*<td class=\"tbdy\">)(.*?)(</td>[\\s]*)"
						+ "(<td class=\"ra\">[\\s]+SCK[\\s]+</td>[\\s]*<td class=\"tbdy\">)(.*?)(</td>[\\s]*)"
						+ "(<td class=\"ra\">[\\s]+FF[\\s]+</td>[\\s]*<td class=\"tbdy\">)(.*?)(</td>[\\s]*)"
						+ "(<td class=\"ra\">[\\s]+INT[\\s]+</td>[\\s]*<td class=\"tbdy\">)(.*?)(</td>[\\s]*)"
						+ "(<td class=\\\"tbdy1\\\"><a href=\\\".*?>)(.*?)(</a></td></tr>)");	
			    
			    String strLine ="";
			    while (input.hasNext()) {
			    	strLine+=input.nextLine();
			    }
			    matcher=pattern.matcher(strLine);
				regex= new Regex[9999];
				
				while(matcher.find()) {
					
					String pos = matcher.group(2);
					pos.trim();
					String number = matcher.group(5);
					String name= matcher.group(8); 
					String status=matcher.group(11);
					String tckl=matcher.group(14);
					String sck=matcher.group(17);
					String intt=matcher.group(23);
					String team=matcher.group(26);
					
					if(number.equals(""))
						number="--";		
					 regex[count]=new Regex(pos,number,name,status,tckl,sck,intt,team);
						count++;
					}
				input.close();	      
		}
		
		// shows the output (scraped data) in a text-area 
		public String display() throws IOException{
			parseData();
			String display="";
			
			for (int i=0;i<count; i++) {
				
				display+=regex[i]+"\n";
			
			}
			return display;
		}
		
		public void writeToFile(String Message) throws FileNotFoundException {
			
			File outputFile = new File("NFLStat.txt");
			// create a file
			PrintWriter output = new PrintWriter(outputFile);
			output.print(Message);
			output.close();// close the file
		}
}
