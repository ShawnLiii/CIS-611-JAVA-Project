package PP04;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;

public class UserGUI extends JFrame implements ActionListener {
	
	
	  private JButton scrapeButton;
	  private JButton closeButton;
	  // add more UI components as needed
	  private Scraper scraper;
	  // UI TextArea&ScrollPane
	  private static JTextArea textArea;
	  private JScrollPane jp;
	  private JLabel outputLabel;
	  private String url;
	  
	  public UserGUI() {
		  
		  initGUI();
		  doTheLayout();
		  scrapeButton.addActionListener(this);
		  closeButton.addActionListener(this);
	   
	  } // end of constructor

	  
	  // Creates and initialize the GUI objects
	  private void initGUI(){
		  outputLabel=new JLabel("Output");
		  scrapeButton=new JButton(" Scrape NFL Page ");
		  closeButton=new JButton(" Close ");
		   //define text area and add it to scroll pane
		   textArea=new JTextArea("Program Output\n",10,48);
		   textArea.setEditable(false);
		   jp=new JScrollPane(textArea);
	  }// end of creating objects method

	
	  // Layouts the UI components as shown in the project document
	  private void doTheLayout(){
		
		  JPanel scrapeBtmLayer=new JPanel();
		  JPanel displayLayer=new JPanel();
	//	  JPanel outputLabelLayer=new JPanel();
		  JPanel closeBtmLayer=new JPanel();
		//set the whole GUI as BouderLayout
		   this.setLayout(new BorderLayout());
		   this.add(scrapeBtmLayer,BorderLayout.NORTH);
		   this.add(displayLayer,BorderLayout.CENTER);
		   this.add(closeBtmLayer,BorderLayout.SOUTH);
		   scrapeBtmLayer.add(scrapeButton);
		   closeBtmLayer.add(closeButton);
		   displayLayer.setLayout(new BorderLayout());
		   displayLayer.add(outputLabel,BorderLayout.NORTH);
		   displayLayer.add(jp,BorderLayout.CENTER);
	  }// end of Layout method

	  public void actionPerformed(ActionEvent e) {
			// Call the required button action method according to the action event
			if(e.getSource()==scrapeButton)
				try {
					scrape();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			else if(e.getSource()==closeButton)
				close();
	  }
	  
	  
	// Uses the Scraper object reference to return and display the data as shown in the project document 
	 private void scrape() throws IOException{
		
		 // uses the url provided in the document
		 scraper=new Scraper(url);
		 url="http://www.nfl.com/players/search?category=position&filter=defensiveback&conferenceAbbr=null&playerType=current&conference=ALL";
		 String display=String.format("%-10s %-10s %-30s %-10s %-10s %-10s %-10s %-5s","Pos","Num","Player Name","Status","TCKL","SCK","INT","Team"+"\n");
		 //String display=String.format(" \t \t \t \t \t \t \t","Pos","Num","Player Name","Status","TCKL","SCK","INT","Team"+"\n");
		 for(int i=1;i<8;i++) {
			 scraper=new Scraper("http://www.nfl.com/players/search?category=position&playerType=current&d-447263-p="+i+"&conference=ALL&filter=defensiveback&conferenceAbbr=null");	
				display+=scraper.display();
			}
		 textArea.setText(display);
		 scraper.writeToFile(display); 
	  }// end of scrape action event method
	  
	 
	 private void close(){
	      System.exit(0);
	  }// end of close action event method


	public static void main(String[] args) {
		//Create a new GUI
		   UserGUI frame = new UserGUI();
		   //Set GUI frame settings
		   frame.setTitle("NFL Stats");
		   frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
		   frame.pack();
		   frame.setLocationRelativeTo(null);
		   frame.setVisible(true);

	}// end of main method

}// end of class
