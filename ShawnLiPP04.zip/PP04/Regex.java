package PP04;
 
public class Regex {

	//pattern attributes
	private String pos;
	private String num;
	private String llayerName;
	private String status;
	private String tckl;
	private String sck;
	private String intt;
	private String team;
	
	//constructor

	public Regex(String pos, String num, String llayerName, String status, String tckl, String sck, String intt, String team) {
		
		super();
		this.pos = pos;
		this.num = num;
		this.llayerName = llayerName;
		this.status = status;
		this.tckl = tckl;
		this.sck = sck;
		this.intt = intt;
		this.team = team;
	}

	public String getPos() {
		return pos;
	}

	public void setPos(String pos) {
		this.pos = pos;
	}

	public String getNum() {
		return num;
	}

	public void setNum(String num) {
		this.num = num;
	}

	public String getLlayerName() {
		return llayerName;
	}

	public void setLlayerName(String llayerName) {
		this.llayerName = llayerName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTckl() {
		return tckl;
	}

	public void setTckl(String tckl) {
		this.tckl = tckl;
	}

	public String getSck() {
		return sck;
	}

	public void setSck(String sck) {
		this.sck = sck;
	}

	public String getIntt() {
		return intt;
	}

	public void setIntt(String intt) {
		this.intt = intt;
	}

	public String getTeam() {
		return team;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	@Override
	public String toString() {
		String outPut; 
		outPut=String.format("%-10s %-10s %-30s %-10s %-10s %-10s %-10s %-10s",
				 pos, num, llayerName, status, tckl, sck, intt, team);
			return outPut;
	}

	// 	add getter and setter methods
	
	
}
