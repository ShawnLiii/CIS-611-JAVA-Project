package PA07; 

public class Faculty extends Person{
	

	
	private String rankOfFaculty; // values are Lecturer, Assistant Professor, Associate professor, Professor
	
	Faculty(String lastName,String firstName, Address address, String phoneNumber, String emailAddress, String rankOfFaculty){
		// call the super class constructor to pass the Person data fields	
		super(lastName,firstName,address,phoneNumber,emailAddress);
		this.rankOfFaculty = rankOfFaculty; // values are Lecturer, Assistant Professor, Associate Professor, Professor
	
	}
 
	
	public String getRankOfFaculty() {
		return rankOfFaculty;
	}


	public void setRankOfFaculty(String rankOfFaculty) {
		this.rankOfFaculty = rankOfFaculty;
	}


	// Override the abstract method from Person
	@Override
	public String toString() {
		return lastName + " , " + firstname + " , "+ address.toString() + " , " + phoneNumber + " , " + emailAddress + " , " + rankOfFaculty;
	}

}
