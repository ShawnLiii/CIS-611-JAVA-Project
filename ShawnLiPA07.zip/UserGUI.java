package PA07;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.FileNotFoundException;
import java.util.*;

import javax.swing.*;

public class UserGUI extends JFrame implements ActionListener{
	
	static Person[] personArray;
	static Person person;
	static Address addressInput;
	static boolean gotCorrect;
    static int a=0;
	static int numberOfPersons = 0,count=0;
	
	// declare all GUI components below
	  private JButton addBtn,sortBtn,displayBtn;
	  private JComboBox personList;
	 // UI RadioButton
	  private JRadioButton facultyButton,studentButton;
	  ButtonGroup group;
	  // UI label
	  private JLabel lastName,firstName,address,phone,eMail;
	  private JTextField txtLastName,txtFirstName,txtAddress,txtPhone,txtEMail; 
	  
	 // UI TextArea&ScrollPane
	  private JTextArea textArea;
	  private JScrollPane jp;
				// constructor
				UserGUI(int nPersons){
					
					
					// create person array of size nPersons
					personArray=new Person[nPersons];
					//Initialize the components
					initComponenet();

					//Organize the GUI components
					doTheLayout();
					
					/*Add the action listeners GUI buttons(add, sort, and display)
					Example: addButton.addActionListener(this);*/
				
					addBtn.addActionListener(this);
					addBtn.setActionCommand("add");
					
					sortBtn.addActionListener(this);
					sortBtn.setActionCommand("sort");
					
					displayBtn.addActionListener(this);
					displayBtn.setActionCommand("display");
					
					facultyButton.addItemListener(new ItemListener(){
				
						public void itemStateChanged(ItemEvent e)
					{
						personList.removeAllItems();
						personList.addItem("Lecturer");
						personList.addItem("Assistant Professor");
						personList.addItem("Associate professor");
						personList.addItem("Professor");
					}
					});
					studentButton.addItemListener(new ItemListener(){
						
						public void itemStateChanged(ItemEvent e)
					{
						personList.removeAllItems();
						personList.addItem("Freshman");
						personList.addItem("Sophomore");
						personList.addItem("Junior");
						personList.addItem("Senior");
					}
					});
								       		
					
				}//End of constructor

				private void initComponenet(){
				
					  // initialize all user interface components
					
						//labels
					   lastName=new JLabel("Last Name");
					   firstName=new JLabel("First Name");
					   address=new JLabel("Address");
					   phone=new JLabel("Phone Number");
					   eMail=new JLabel("eMail");
					   
					   //text fields
					   txtLastName=new JTextField(20);
					   txtFirstName=new JTextField(20);
					   txtAddress=new JTextField(25);
					   txtPhone=new JTextField(20);
					   txtEMail=new JTextField(20);
					   
					   // Radio Buttons
					   facultyButton=new JRadioButton("Faculty");
					   studentButton=new JRadioButton("Student");
					   
					   // Radio Buttons to ButtonGroup
					   group=new ButtonGroup();
					   group.add(facultyButton);
					   group.add(studentButton);
					   
					   //define text area and add it to scroll pane
					   textArea=new JTextArea("Program Output\n",10,48);
					   textArea.setEditable(false);
					   jp=new JScrollPane(textArea);
					   
					  // buttons 
					   addBtn=new JButton(" Add Student/Faculty ");
					   sortBtn=new JButton(" Sort Student&Faculty ");
					   displayBtn=new JButton(" Display Student&Faculty ");
					   
					   //Combo Box
		
					   personList=new JComboBox();
				
				
				      
			  
				}

			   private void doTheLayout(){
					// Organize the components into GUI window
		
				   
				   
				   JPanel top=new JPanel();
				   JPanel center=new JPanel();
				   JPanel centerTop=new JPanel();
				   JPanel centerBottom=new JPanel();
				   JPanel bottom=new JPanel();
				   JPanel bottomTop=new JPanel();
				   JPanel bottomBottom=new JPanel();
				   
				   
				   
				   // set Layout for the top Panel
				   top.setLayout(new GridLayout(5,2));		   
				    
				   // add components to the top user Information Panel
				   top.add(lastName);  top.add(txtLastName);
				   top.add(firstName); top.add(txtFirstName);
				   top.add(address); top.add(txtAddress);
				   top.add(phone); top.add(txtPhone);
				   top.add(eMail); top.add(txtEMail);
				   
				   //set Layout to the center Panel
				   
				   center.setLayout(new BorderLayout());
				   
				   //add components to the center top user Status Panel faculty or student
				   
				   
				   centerTop.add(facultyButton);
				   centerTop.add(studentButton); 
				  // add components to the center bottom faculty's rank list 
				   
				   centerBottom.add(personList);
				   
				   // add components to the student's status list 
				   
				// centerBottom.add(studentList);
				   
				   //set Layout to the bottom Panel
				   bottom.setLayout(new BorderLayout());
				   // add components to the bottom top function Panel
				   
				   bottomTop.add(addBtn);
				   bottomTop.add(sortBtn);
				   bottomTop.add(displayBtn);
				   // add components to the bottom bottom display Panel
				   bottomBottom.add(jp);
				   
				   center.add(centerTop, BorderLayout.NORTH);
				   center.add(centerBottom, BorderLayout.CENTER);
				   bottom.add(bottomTop, BorderLayout.NORTH);
				   bottom.add(bottomBottom, BorderLayout.CENTER);
				   
				   //add the panels to the GUI content pane
				   
				   this.add(top, "North");
				   this.add(center, "Center");
				   this.add(bottom, "South");
				
				   
				}

				
				@Override
				public void actionPerformed(ActionEvent e) {
					// Call the required button action method according to the action event
					if(e.getSource()==addBtn)
						addButtonClicked();
					else if(e.getSource()==sortBtn)
						sortBnttonClicked();
					else if (e.getSource()==displayBtn)
						try {
							displaynttonClicked();
						} catch (FileNotFoundException e1) {
							e1.printStackTrace();
						}
				}
			   
				private void addButtonClicked(){
					
					//Method to implement add button action
					
					String lastName="",firstName="",address="",eMail="";
					String phoneNumber=" ";
					String street="";
					String city="";
					int houseNumber=0,zipCode=0;
					String state="";
					//input last name
					if(txtLastName.getText().isEmpty()){
						JOptionPane.showMessageDialog(txtLastName,"Invalid Last name");
						txtLastName.setText("");
						return;
					}else
						lastName=txtLastName.getText();
					//input first name
					if(txtFirstName.getText().isEmpty()){
						JOptionPane.showMessageDialog(txtFirstName,"Invalid First name");
						txtFirstName.setText("");
						return;
					}else
						firstName=txtFirstName.getText();
					//input address
					if(txtAddress.getText().isEmpty()){
						JOptionPane.showMessageDialog(txtAddress,"Invalid Address\nNote: Please input address by the following format:\nstreet,houseNumber,city,state,zipCode\nsplit by',' without space");
						txtAddress.setText("");
						return;
					}else
						address=txtAddress.getText();
					
					String fields[] = address.split(",");
					
					
					
						try {
							 street=fields[0];
						
						}catch (Exception ex) {
							JOptionPane.showMessageDialog(null,"Invalid street\nNote: Please input address by the following format:\nstreet,houseNumber,city,state,zipCode\nsplit by',' without space");	
							txtAddress.setText("");
							return;
						}
							
					
				
						try {
							houseNumber=Integer.parseInt(fields[1]);
						
						}catch (Exception ex) {
							JOptionPane.showMessageDialog(null,"Invalid house number\nNote: Please input address by the following format:\nstreet,houseNumber,city,state,zipCode\nsplit by',' without space");	
							txtAddress.setText("");
							return;
						}
							
					
					
						try {
							
							city=fields[2];
						
						}catch (Exception ex) {
							JOptionPane.showMessageDialog(null,"Invalid city\nNote: Please input address by the following format:\nstreet,houseNumber,city,state,zipCode\nsplit by',' without space");	
							txtAddress.setText("");
							return;
						}
						
					
					
						try {
							state=fields[3];
						
						}catch (Exception ex) {
							JOptionPane.showMessageDialog(null,"Invalid state\nNote: Please input address by the following format:\nstreet,houseNumber,city,state,zipCode\nsplit by',' without space");	
							txtAddress.setText("");
							return;
						}
							
					
						try {
							zipCode=Integer.parseInt(fields[4]);
						
						}catch (Exception ex) {
							JOptionPane.showMessageDialog(null,"Invalid zipcode\nNote: Please input address by the following format:\nstreet,houseNumber,city,state,zipCode\nsplit by',' without space");	
							txtAddress.setText("");
							return;
						}
							
				
					Address ad=new Address(street,houseNumber,city,state,zipCode);
					
					
					//input phone number, 
					if(txtPhone.getText().isEmpty()){
						JOptionPane.showMessageDialog(txtPhone,"Invalid Phone number");
						txtPhone.setText("");
						return;
					}else
						phoneNumber=txtPhone.getText();
					//input email address
					if(txtEMail.getText().isEmpty()){
						JOptionPane.showMessageDialog(txtEMail,"Invalid Email Address");
						txtEMail.setText("");
						return;
					}else
						eMail=txtEMail.getText();
		//			// based on selected radio button call method Faculty or Student
					
					String status = "";							
		//			// call the person object
					if((studentButton.isSelected()||facultyButton.isSelected())==false) {
						JOptionPane.showMessageDialog(null,"Please select a person status");
						return;
					}else if(facultyButton.isSelected()){
						status= personList.getSelectedItem().toString();
						if( count< numberOfPersons )
							person = new Faculty(lastName,firstName,ad,phoneNumber,eMail,status);
						else{
							JOptionPane.showMessageDialog(null,"You can't add more people");
						 }
						
					}
					else if(studentButton.isSelected()){
						status=personList.getSelectedItem().toString();
						if( count< numberOfPersons )
							person =new Student(lastName,firstName,ad,phoneNumber,eMail,status);
						else {
							JOptionPane.showMessageDialog(null,"You can't add more people");
						}
							
					}
				
					
					
					//add it to the array
					if( count< numberOfPersons )
					{
						personArray [count] = person;
						String output="";
					    output+=personArray[count].toString();
						textArea.setText(output);
						count++;
					}
					
					else{
						JOptionPane.showMessageDialog(null,"You can't add more people");
					}
					
					
					
					//clear text fields from data
					txtLastName.setText("");
					txtFirstName.setText("");
					txtAddress.setText("");
					txtPhone.setText("");
					txtEMail.setText("");
					

					
				}

						
				private void sortBnttonClicked() {
					//Method to implement sort button action
					selectionSort();
					
			}

				private void displaynttonClicked() throws FileNotFoundException{
					
					// Method to implement display button action
					
					//if user wants to display before they input all the information
					if (count< numberOfPersons) {
						JOptionPane.showMessageDialog(null,"You need to add "+(numberOfPersons-count)+" more person");
						return;
					}
					
					// calls the selection sort to sort the personArray
					
					 sortBnttonClicked();
					
					// displays the array in the text area after sorting
					
					String output="";
					for (int i=0;i<numberOfPersons;i++) {
						output+=personArray[i].toString()+"\n";
					}
					
					textArea.setText(output);
					
				}
				
				
				private void selectionSort() {
				//Method to sort person objects based on last name	
	
					for(int i=0;i<numberOfPersons;i++)
					{
						for(int j=i+1;j<numberOfPersons;j++)
						{
							if(personArray[i].getLastName().compareTo(personArray[j].getLastName())>1)
							{
								Person temp = personArray[i];
								personArray[i]=personArray[j];
								personArray[j]=temp;
							}
						}
					}
						
				}
				
						
			public static void main(String[] args) throws FileNotFoundException {
						
				//declare variables
				

				//Input number of audiences
				
				
				
				while(!gotCorrect){
					try {
						numberOfPersons=Integer.parseInt(JOptionPane.showInputDialog(null," Enter number of person,example,enter a value of 2"));
					break;
					}catch (Exception ex) {
						JOptionPane.showMessageDialog(null," Invalid input ");	
						continue;
					}
						}
				//Create a new GUI
				UserGUI frame = new UserGUI(numberOfPersons);

				//Set GUI frame settings
				frame.setTitle(" User information management system ");
				frame.pack();
				frame.setLocationRelativeTo(null);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setVisible(true);
			}// end main
			
	
	}
