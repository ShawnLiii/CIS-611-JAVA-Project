
package PA07; 

public class Student extends Person{
	

	private String status; // Values are Freshman, Sophomore, Junior, Senior 
	
	Student(String lastName, String firstName, Address address, String phoneNumber, String emailAddress, String status){
		// call the super class constructor to pass the Person data fields	
		super(lastName,firstName,address,phoneNumber,emailAddress);
		this.status = status;
	}
	
	// Override the abstract method from Person
	
	@Override
	public String toString() {
		return lastName + " , "+ firstname + " , "+ address.toString() + " , " + phoneNumber + " , " + emailAddress+" , "+ status;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
