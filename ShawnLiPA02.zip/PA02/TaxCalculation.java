import javax.swing.*;

public class TaxCalculation {

	public static void main(String[] args) {
		
		String userInputIncome=JOptionPane.showInputDialog(null,"Enter income of one person.Enter value as a whole number, "
				+ "without any decimal, e.g.,15125");
		double income = Double.parseDouble(userInputIncome);
		String status=JOptionPane.showInputDialog(null,"Enter status of person, Enter either the value of Single, or Married.");
		int statusInInt = 0;
		 switch(status){	   
	            case "Single":
	            	statusInInt = 0;
	                break;
	            case "Married":
	            	statusInInt = 1;
	                break;
	            default:
	            	JOptionPane.showMessageDialog(null,"no match");
	            	System.exit(0);
	        }
		 double tax = 0.0;
		 if (statusInInt==0) {
			 if(income>=0&&income<=8350.0){
				 tax=income*0.1;
		 }
			 else if(income>=8351.0&&income<=33950.0) {
				 tax=835.0+(income-8350.0)*0.15;
			 }
			 else if(income>=33951.0&&income<=82250.0) {
				 tax=835.0+3840.0+(income-33950.0)*0.25;
			 }
			 else if(income>=82251.0&&income<=171550.0) {
				 tax=835.0+3840.0+12075.0+(income-82250.0)*0.28;
			 }
			 else if(income>=171551.0&&income<=372950.0) {
				 tax=835.0+3840.0+12075.0+25004.0+ (income-171550.0)*0.33;
			 }
			 else if(income>=372951.0) {
				 tax=835.0+3840.0+12075.0+25004.0+66462+ (income-372950.0)*0.35;
			 }
			 else {
				 JOptionPane.showMessageDialog(null,"Please input a positive number");
				 System.exit(0);
			 }
		 					}
		 if (statusInInt==1) {
			 if(income>=0&&income<=16700.0){
				 tax=income*0.1;
		 }
			 else if(income>=16701.0&&income<=67900.0) {
				 tax=1670.0+(income-16700.0)*0.15;
			 }
			 else if(income>=67901.0&&income<=137050.0) {
				 tax=1670.0+7680.0+(income-67900.0)*0.25;
			 }
			 else if(income>=137051.0&&income<=208850.0) {
				 tax=1670.0+7680.0+17287.5+(income-137050.0)*0.28;
			 }
			 else if(income>=208851.0&&income<=372950.0) {
				 tax=1670.0+7680.0+17287.5+20104.0+(income-208850.0)*0.33;
			 }
			 else if(income>=372951.0) {
				 tax=1670.0+7680.0+17287.5+20104.0+54153.0+(income-372950.0)*0.35;
			 }
			 else {
				 JOptionPane.showMessageDialog(null,"Please input a positive number");
				 System.exit(0);
			 }
		 }
		 JOptionPane.showMessageDialog(null, "Income = $"+ income + "\n"+
					"Status = "+status + "\n"+ 
					"Tax= $" + String.format("%.1f",tax));

}
}
