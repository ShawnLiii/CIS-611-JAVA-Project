import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

public class RegexPractice {

	public static void main(String[] args) throws IOException {
		//define Pattern and Matcher objects
		String itemRegex="title=\"(.*?)\"(.*?)\"Suggested Retail Price:\\s(.*?)\"";
		Pattern itemPattern=Pattern.compile(itemRegex);
		Matcher itemMatcher=null;
		//Define a PrintWriter object to store the program output
		File file = new File("matcherout.txt");
		PrintWriter output = new PrintWriter(file);
		
		//use the scanner to read the data
		Scanner sc=new Scanner(new File("RetailStore.txt"));
		//Declare variables: count the match time
		int matchTime = 0; 
		String strOutput="Scraper Program Output:\n";
		String strLine = "";
		//create one string input of the file content
		while (sc.hasNext())
			strLine+=sc.nextLine();
		//initial the matcher object
		itemMatcher=itemPattern.matcher(strLine);
		//search for the pattern matches into the matcher objects
		while (itemMatcher.find()) {
			strOutput+="Title = "+itemMatcher.group(1)+"\tSuggested Retail Price= "+itemMatcher.group(3)+"\n";
			matchTime++;
		}
		//write program output to a file
		output.print(strOutput+"\n"+"Number of Matched Items: "+matchTime);
		//closed files
		sc.close();
		output.close();
		//display the output
		JOptionPane.showMessageDialog(null,new JTextArea(strOutput+"\n"+"Number of Matched Items: "+matchTime));
		

		  
		  
	}

}
