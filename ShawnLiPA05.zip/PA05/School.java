//*********************************************************************
//*                                                                   *
//*    CIS611             Spring Semester 2019              Shawn Li  *
//*                                                                   *
//*                    Programming Assignment PA05                    *
//*                                                                   *
//*                         School Class                              *
//*                                                                   *
//*                                                                   *
//*                             3/8/2019                              *
//*                                                                   *
//*                    Saved in: School.java                   		  *
//*                                                                   *
//*********************************************************************
package PA05;

import javax.swing.JOptionPane;

public class School {
	
	private static Course course;

	public static void main(String[] args) {
		
			boolean gotCorrect = false;
			int n=0,id=0,courseId=0;
			String name=" ",description="",assignment="";
			double score=0;
			
		// 1 - prompt the user to provide the number of students, integer n value
		
		while(!gotCorrect){
			try {
			n =Integer.parseInt(JOptionPane.showInputDialog(null,"How many students?"));; 
					 break;
			}catch (Exception ex) {
			JOptionPane.showMessageDialog(null,"The number of students must be an integer. ");
			continue;
			}
						 }
		
		// 2 - Instantiates the course object
		while(!gotCorrect){
			try {
		courseId=Integer.parseInt(JOptionPane.showInputDialog(null,"Please input the course id"));
		break;
			}catch (Exception ex) {
			JOptionPane.showMessageDialog(null,"The number of course id must be an integer. ");
			continue;
			}
			
		}
		description=JOptionPane.showInputDialog(null,"Please input the course description");	
		course=new Course(courseId,description,n);
		// 3 - Prompt the user to input the student data, and calls addStudentGrade() to add the student to course, for n students
		for(int i=0;i<n;i++) {
		while(!gotCorrect){
			try {
		id=Integer.parseInt(JOptionPane.showInputDialog(null,"Please input the student id"));
		break;
			}catch (Exception ex) {
				JOptionPane.showMessageDialog(null,"The number of student's id must be an integer.");
				continue;
				}	
			
			}
		name=JOptionPane.showInputDialog(null,"Please input the student's name");
		addStudentToCourse(id,name);
		
		// 4 - Prompt the user to input the grade data, and calls aaddStudentGradeToCourse() to add the grade to course, for n grades
		
			
			assignment=JOptionPane.showInputDialog(null,"Please input the assignment name");
			while(!gotCorrect){
				try {
			score=Double.parseDouble(JOptionPane.showInputDialog(null,"Please input the student grade"));
			break;
				}catch (Exception ex) {
					JOptionPane.showMessageDialog(null,"Please input valid grade");
					continue;
					}	
				}
			addStudentGradeToCourse(id,assignment,new Student(id,name),score);
		}
		// 5 - Displays the course statistics by calling displayCourseStat()
			displayCourseStat();
			
		
	}
		
	
	
	
	
	// it uses the course object to add a new student to the course
	public static void addStudentToCourse(int id, String name){
		
		course.addStudent(id, name);
	}
	
	// it uses the course object to add a new grade object to the course
	public static void addStudentGradeToCourse(int id, String assignment, Student student, double score){
			course.addGrade(id, assignment, student, score);
	}
	
	// it should display the grade average and the highest student grade, student name 
	public static void displayCourseStat(){
		JOptionPane.showMessageDialog(null,course.toString()+"\n"+"The average score is "+ String.format("%.2f",course.getGradeAVG())+"\n"+"The higest Grade is from "+course.getHiegestStudentGrade());
	}

}

