//*********************************************************************
//*                                                                   *
//*    CIS611             Spring Semester 2019              Shawn Li  *
//*                                                                   *
//*                    Programming Assignment PA05                    *
//*                                                                   *
//*                         Course Class                              *
//*                                                                   *
//*                                                                   *
//*                             3/8/2019                              *
//*                                                                   *
//*                    Saved in: Course.java                   		  *
//*                                                                   *
//*********************************************************************
package PA05;

public class Course {
	
	private int id;
	private String description;
	private Student[] students;
	private Grade[] grades;
	private int n;
	private int studentCount=0,gradeCount=0;
	
	// complete course object constructor
	public Course (int id, String description, int n){
		// you should initialize the students and grades arrays here
		// these array should be of size n 
		this.id = id;
		this.description = description;
		this.n=n;
		
		students=new Student [n];
		grades=new Grade[n];
	}

	// Creates and adds a student object to the students array

	public void addStudent(int id, String name){
		Student s = new Student(id,name);
		students[studentCount]=s;
		studentCount++;
	}

	// adds a grade object to the  grades array

   public void addGrade(int id,String assignment,Student student,double score){
	   
		Grade g = new Grade(id,assignment,student,score);
	   grades[gradeCount]=g;
	   gradeCount++;			
	}
   
   
   
   public double getGradeAVG(){
	   double sum=0;
	   for(int i=0;i<n;i++) {
		   sum+=grades[i].getScore();
	   }
	   return sum/n;
		
	}
   
   
  public String getHiegestStudentGrade(){
	   Grade max=grades[0];
	   for (int i=1;i<n;i++) {
		   if(grades[i].getScore()>max.getScore()) {
			   max=grades[i];
		   }
	   }
	   return max.getStudent().getName();
		
	}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getDescription() {
	return description;
}

public void setDescription(String description) {
	this.description = description;
}

public String getStudents() {
	String output="";
	for (int i=0;i<n;i++) {
		output+=students[i]+"\n";
	}
	return output;
}


public String getGrades() {
	String outputScore="";
	for (int i=0;i<n;i++) {
		outputScore+=grades[i]+"\n";
	}
	return outputScore;
}

public void setGrades(Grade[] grades) {
	this.grades = grades;
}

@Override
public String toString() {
	return "Course [ id= " + id + ", description= " + description + "]\n" + getStudents() + getGrades();
}
   
   
}
