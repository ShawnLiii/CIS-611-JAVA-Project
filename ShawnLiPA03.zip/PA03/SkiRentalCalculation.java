import javax.swing.*;
import java.math.BigDecimal;
public class SkiRentalCalculation {

	public static void main(String[] args) {
		String output=" ";
		
		double SALES_TAX_PERCENTAGE=0.075;
		boolean gotCorrect = false;
		int numberOfCustomers=0,daysInInt=0,numberOfUnits=0,stateOfUser=0,hasCupon=0,hasMembership=0;
		  
		double chargePerPerson=0,chargePerPersonKeepTwoDecimal=0;
		
		while(!gotCorrect){
			
			String numberOfSkiCustomers =JOptionPane.showInputDialog(null,"Enter the number of ski customers in whole number, e.g., 3"); 
			
		try {
					 numberOfCustomers = Integer.parseInt(numberOfSkiCustomers);
					 break;
		}catch (Exception ex) {
			JOptionPane.showMessageDialog(null,"The number of ski customers must be an integer. ");
			continue;
		}
						 }
		
		String[] namesArr = new String[numberOfCustomers];
		 double[] valuesArr = new double[numberOfCustomers];
	
		 
		 
		 
		 
		 for(int i=0;i<namesArr.length;i++) {
				 
		 while(!gotCorrect) {
			try {
			  namesArr[i]= JOptionPane.showInputDialog(null,"Enter the Name of the customer,\nNote: Please input First name and then Last name. Separate your name with a spaces, e.g., John Doe.");
			  break;
		  }catch(Exception ex){
				JOptionPane.showMessageDialog(null,"Please input correct information of the name");
				continue;
			}
		 }
		while(!gotCorrect) {
			try {	
			 String numberOfDays =JOptionPane.showInputDialog(null,"Enter the number of days, e.g., 3");
			 daysInInt = Integer.parseInt(numberOfDays);
			 break;
			}catch (Exception ex) {
				JOptionPane.showMessageDialog(null,"The number of days must be an integer. ");
				continue;
			}
								}
			
			while(!gotCorrect){
			try {
			String numberOfRentalUnits =JOptionPane.showInputDialog(null,"Enter the number of the rental units, \nthe acceptable values are 0, 1, 2, 3");
			numberOfUnits = Integer.parseInt(numberOfRentalUnits);
			if(numberOfUnits==0||numberOfUnits==1||numberOfUnits==2||numberOfUnits==3) 
			 break;
			else {
				JOptionPane.showMessageDialog(null,"The number of rental units must be an integer 0, 1, 2 and 3. ");
				continue;
			}
				}catch(Exception ex){
					JOptionPane.showMessageDialog(null,"The number of rental units must be an integer of 0, 1, 2 and 3. ");
					continue;
					}
			}
			
					 stateOfUser =JOptionPane.showConfirmDialog(null,"Is the ski custome a first time user?");
					 if (stateOfUser==2||stateOfUser==-1) 
						 System.exit(0);	 
					 hasCupon=JOptionPane.showConfirmDialog(null,"Does the ski custome have a cupon?");
					 if (hasCupon==2||hasCupon==-1)
						 System.exit(0);
					 hasMembership=JOptionPane.showConfirmDialog(null,"Does the ski custome have a membership?");
					 if (hasMembership==2||hasMembership==-1)
						 System.exit(0);
					 
			if (stateOfUser==0&&numberOfUnits==0) {
				if(hasMembership==0) {
				if(hasCupon==0) {
				chargePerPerson=(60*daysInInt*0.85)*(1+SALES_TAX_PERCENTAGE)-5;
				}else if(hasCupon==1){
				chargePerPerson=(60*daysInInt*0.85)*(1+SALES_TAX_PERCENTAGE);
				}
				 }else if(hasMembership==1) {
					if(hasCupon==0) {
						chargePerPerson=(60*daysInInt*0.9)*(1+SALES_TAX_PERCENTAGE)-5;
					}else if(hasCupon==1){
						chargePerPerson=(60*daysInInt*0.9)*(1+SALES_TAX_PERCENTAGE);
											}	
									}
			}
			if (stateOfUser==0&&(numberOfUnits==1||numberOfUnits==2||numberOfUnits==3)) {
				
				if(hasMembership==0) {
					if(hasCupon==0) {
						if(numberOfUnits==1) {
							chargePerPerson=(110*daysInInt*0.8)*(1+SALES_TAX_PERCENTAGE)-10;
						}else if(numberOfUnits==2){
							chargePerPerson=(155*daysInInt*0.8)*(1+SALES_TAX_PERCENTAGE)-10;
						}else if(numberOfUnits==3) {
							chargePerPerson=(190*daysInInt*0.8)*(1+SALES_TAX_PERCENTAGE)-10;
						}
					}else if(hasCupon==1){
						if(numberOfUnits==1) {
							chargePerPerson=(110*daysInInt*0.8)*(1+SALES_TAX_PERCENTAGE);
						}else if(numberOfUnits==2){
							chargePerPerson=(155*daysInInt*0.8)*(1+SALES_TAX_PERCENTAGE);
						}else if(numberOfUnits==3) {
							chargePerPerson=(190*daysInInt*0.8)*(1+SALES_TAX_PERCENTAGE);
						}
					}
				}	
			   if(hasMembership==1) {
				if(hasCupon==0) {
					if(numberOfUnits==1) {
						chargePerPerson=(110*daysInInt*0.88)*(1+SALES_TAX_PERCENTAGE)-10;
					}else if(numberOfUnits==2){
						chargePerPerson=(155*daysInInt*0.88)*(1+SALES_TAX_PERCENTAGE)-10;
					}else if(numberOfUnits==3) {
						chargePerPerson=(190*daysInInt*0.88)*(1+SALES_TAX_PERCENTAGE)-10;
					}
				}else if(hasCupon==1){
					if(numberOfUnits==1) {
						chargePerPerson=(110*daysInInt*0.88)*(1+SALES_TAX_PERCENTAGE);
					}else if(numberOfUnits==2){
						chargePerPerson=(155*daysInInt*0.88)*(1+SALES_TAX_PERCENTAGE);
					}else if(numberOfUnits==3) {
						chargePerPerson=(190*daysInInt*0.88)*(1+SALES_TAX_PERCENTAGE);
					}
				}
			}
			}
			
			if (stateOfUser==1&&hasMembership==0&&numberOfUnits==0) {
				if(hasCupon==0){
					chargePerPerson=(60*daysInInt*0.95)*(1+SALES_TAX_PERCENTAGE)-5;
					}else if(hasCupon==1){
					chargePerPerson=(60*daysInInt*0.95)*(1+SALES_TAX_PERCENTAGE);
					}
			}
			if (stateOfUser==1&&hasMembership==0&&(numberOfUnits==1||numberOfUnits==2||numberOfUnits==3)) {
				if(hasCupon==0) {
					if(numberOfUnits==1) {
						chargePerPerson=(110*daysInInt*0.92)*(1+SALES_TAX_PERCENTAGE)-10;
					}else if(numberOfUnits==2){
						chargePerPerson=(155*daysInInt*0.92)*(1+SALES_TAX_PERCENTAGE)-10;
					}else if(numberOfUnits==3) {
						chargePerPerson=(190*daysInInt*0.92)*(1+SALES_TAX_PERCENTAGE)-10;
					}
				}else if(hasCupon==1){
					if(numberOfUnits==1) {
						chargePerPerson=(110*daysInInt*0.92)*(1+SALES_TAX_PERCENTAGE);
					}else if(numberOfUnits==2){
						chargePerPerson=(155*daysInInt*0.92)*(1+SALES_TAX_PERCENTAGE);
					}else if(numberOfUnits==3) {
						chargePerPerson=(190*daysInInt*0.92)*(1+SALES_TAX_PERCENTAGE);
					}
				}
			}
			
			if (stateOfUser==1&&hasMembership==1&&numberOfUnits==0) {
				if(hasCupon==0){
					chargePerPerson=60*daysInInt*(1+SALES_TAX_PERCENTAGE)-5;
					}else if(hasCupon==1){
					chargePerPerson=60*daysInInt*(1+SALES_TAX_PERCENTAGE);
					}
			}
			if (stateOfUser==1&&hasMembership==1&&(numberOfUnits==1||numberOfUnits==2||numberOfUnits==3)) {
				if(hasCupon==0) {
					if(numberOfUnits==1) {
						chargePerPerson=110*daysInInt*(1+SALES_TAX_PERCENTAGE)-10;
					}else if(numberOfUnits==2){
						chargePerPerson=155*daysInInt*(1+SALES_TAX_PERCENTAGE)-10;
					}else if(numberOfUnits==3) {
						chargePerPerson=190*daysInInt*(1+SALES_TAX_PERCENTAGE)-10;
					}
				}else if(hasCupon==1){
					if(numberOfUnits==1) {
						chargePerPerson=110*daysInInt*(1+SALES_TAX_PERCENTAGE);
					}else if(numberOfUnits==2){
						chargePerPerson=155*daysInInt*(1+SALES_TAX_PERCENTAGE);
					}else if(numberOfUnits==3) {
						chargePerPerson=190*daysInInt*(1+SALES_TAX_PERCENTAGE);
					}
				}
			}
			
			BigDecimal bg = new BigDecimal(chargePerPerson);
			
			chargePerPersonKeepTwoDecimal=bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
			
			valuesArr[i]=chargePerPersonKeepTwoDecimal;
			
			output+="Name: "+namesArr[i]+", $"+valuesArr[i]+"\n";
		
		   										}
		 
		
		JOptionPane.showMessageDialog(null,output);
		
		
}
}
	



