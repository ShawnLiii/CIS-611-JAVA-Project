package PP2;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.JOptionPane;

public class Payment {

	public static Validation validating;	
	public static HashCode hashing;
	public static Customer[] customers;
	static  int n=0,i=0;
	

	// this will check whether a card is valid
	public static Boolean isValidCard(String number){
		
		return validating.aValidNumber(number);

	}// end of the isValidCard method

	// creates a hash code for the credit card number to be stored in file
    public static String createHashCode(String number){
    	
    	return hashing.getHashCode(number);

	}// end of the createHashCode method


     // it adds a new customer to the array of customers once the payment was successful
 	 public static void addCustomer(String fName,String lName,int id,double amount,CreditCard card){
 		 
 		 Customer customer=new Customer(fName,lName,id,amount,card);
 			 customers[i]=customer;
 		 
 		
 	 } // end of the addCustomer method


	// !!!!it displays the payments AVG, MAX payment, and MIN payment,
	// !!!!only for accepted payments with valid cards
 	 public static double Max() {
 		
 		Customer max=customers[0];
		   for (int i=1;i<n;i++) {
			   if(customers[i].getAmount()>max.getAmount()) {
				   max=customers[i];
			   }
		   }
		   return max.getAmount();
        }
 	 
 	 public static double Min() {
 		Customer min=customers[0];
		   for (int i=1;i<n;i++) {
			   if(customers[i].getAmount()<min.getAmount()) {
				   min=customers[i];
			   }
		   }
		   return min.getAmount();   
        }
  

 	 public static double Avg() {
 		double sum=0;
 	    double avr;
 	    for (int i = 0; i < n; i++) {
 	        sum+=customers[i].getAmount();
 	    }
 	    avr=sum/n;
 	    return avr;
 	 }
 	 
	public static void displayStat(){		
		JOptionPane.showMessageDialog(null,"The payment average amount is "+Avg()+"\n"+"The max payment amount is "+Max()
		+"\n"+"The minimum payment amount is "+Min());
	}// end of the displayStat method


	// write data to file, the credit card number should be encrypted
	// using one-way hash method in the Hashing class
    public static void writeToFile(Customer[] customers, String hashcode)throws IOException{
    	
    	File file = new File("Customer.txt");
	    // Create a file
		 PrintWriter output = new PrintWriter(file);
	  	// read data from arrays
		 String info=" ";
	  // Program output
	  for(int i=0;i<n;i++) {  
		  info+=customers[i]+" Card number: "+hashcode+" \n";
	  }
	  //write formatted output to the file
	  output.write(info);
	    // Close the file
	    output.close();
    } // end of the writeToFile method


	// the main entry method of the program that will get data from user and
	// perform the business logic
	public static void main(String[] args) throws IOException {
		String fName;
		String lName;
		hashing = new HashCode();
		validating = new  Validation();
        boolean gotCorrect=false;
        double	amount = 0;
		// input the number of customers and store it into variable n
		while(!gotCorrect){
			try {
				n=Integer.parseInt(JOptionPane.showInputDialog(null,"How many customers?"));
		break;
			}catch (Exception ex) {
				JOptionPane.showMessageDialog(null,"Please input int number");
				continue;
				}	
			}
		
		customers = new Customer[n];
		String number=" ";
		int custId=0;
		long numberinLong=0; 
		for(i=0;i<n;i++) {
			
			while(!gotCorrect){
					try {
						custId=	Integer.parseInt(JOptionPane.showInputDialog(null,"Please input customer's ID\nNote: Input 0 for exit"));	
				break;
					}catch (Exception ex) {
						JOptionPane.showMessageDialog(null,"Please input int number");
						continue;
						}	
					}
			 
			if(custId==0) {
				n=i;
				break;
			}
			
			while(!gotCorrect){
				try {
					number=JOptionPane.showInputDialog(null,"Please input the credit card number");	
					numberinLong=Long.parseLong(number);
					break;
				}catch (Exception ex) {
					JOptionPane.showMessageDialog(null,"Please input int number");
					continue;
					}	
				}
			
		
		
		if(isValidCard(number)) {	
					fName=JOptionPane.showInputDialog(null,"Please input customer's First Name");
					lName = JOptionPane.showInputDialog(null,"Please input customer's Last Name");
					
				while(!gotCorrect){
					try {
						amount=	Double.parseDouble(JOptionPane.showInputDialog(null,"Please input the amount"));	
				break;
					}catch (Exception ex) {
						JOptionPane.showMessageDialog(null,"Please input correct number");
						continue;
						}	
					}
			String expDate=	JOptionPane.showInputDialog(null,"What is the expiration date?");
			 CreditCard card = new CreditCard(numberinLong, expDate);
			addCustomer(fName, lName, custId, amount,card);
			
		}else {
			
			JOptionPane.showMessageDialog(null,"Card number is not valid");
			i--;
		}
	}
		
		displayStat();
		
		writeToFile(customers,hashing.getHashCode(number));

	}

}
