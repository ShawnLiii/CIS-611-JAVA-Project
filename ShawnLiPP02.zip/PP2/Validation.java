package PP2;

public class Validation {


  // Return true if the card number is valid, otherwise returns false, this method is already implemented
  public boolean aValidNumber(String n) {

	long number = Long.parseLong(n);
	return  (numLength(number) >= 13) && (numLength(number) <= 16) &&
       ((prefixCheck(number, 4) || prefixCheck(number, 5) ||
        prefixCheck(number, 6) || prefixCheck(number, 37)) )&&
        (totalEevenNumbers(number) + totalOddNumbers(number)) % 10 == 0;
  }// end of aValidNumber method

  //get the sum of even places numbers, Starting from the second digit from right
  private int totalEevenNumbers(long number) { 
      int evenTotal = 0;
	  String numberInStr=String.valueOf(number);
	
		int length = numberInStr.length();
		int[] digit = new int[length];
		
		for (int i = 0; i < numberInStr.length(); i++) {
			
			digit[i] = Integer.parseInt(numberInStr.substring(length - i - 1, length
					- i));	
		}
		
		for (int i = 0; i < length / 2; i++) {
			
			evenTotal += singleDigit(digit[2 * i + 1]);
		
	}
	 return evenTotal;
}// end of totalEevenNumbers method

// Return the same number if it is a single digit, otherwise, return the sum of
// the two digits in this number
  private int singleDigit(int number) {
	  
			if (number * 2 > 9) 
				
				number = number * 2 - 9;
			
			else 
				number *= 2;
					
  return number;
} // end of singleDigit method



// Return the sum of odd place digits in number
 private int totalOddNumbers(long number) {
	  
	  int oddTotal = 0;
	  String numberInStr=String.valueOf(number);
		int length = numberInStr.length();
		int[] digit = new int[length];
		
		for (int i = 0; i < numberInStr.length(); i++) {
			
			digit[i] = Integer.parseInt(numberInStr.substring(length - i - 1, length
					- i));	
		}
		if(length%2==1) {
		for (int i = 0; i < (length / 2)+1; i++) {
			
			oddTotal += digit[2 * i];
			
		}
	}else {
		for (int i = 0; i < (length / 2); i++) {
			
			oddTotal += digit[2 * i];
			
	}
		}
		 return oddTotal;

}// end of totalOddNumbers method

// Return true if the digit d is a prefix for number
 private boolean prefixCheck(long number, int d) {
	  
	 long digits;
	  if(d ==37)
		  digits = numPrefix(number,2);
	  else
		  digits=numPrefix(number,1);
	if(digits == d)
		return true;
	else
		return false;
}// end of prefixCheck method


// Return the number of digits in this number parameter
 private int numLength(long number) {
	  String numberString = Long.toString(number);
	  return numberString.length();
}// end of numLength method

// Return the first k number of digits from number, which is either a first digit or first two digits
// Depending on the card type
 private long numPrefix(long number, int k) {
	  
	  String numberString = Long.toString(number);
	  String digits = numberString.substring(0, k); 
	 number = Long.parseLong(digits);
	 return number;
}// end of numPrefix method

}// end of the class