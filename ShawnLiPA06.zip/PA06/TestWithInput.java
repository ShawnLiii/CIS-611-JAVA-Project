package PA06;

import javax.swing.JOptionPane;

public class TestWithInput {
	static Person[] personArray;
	static Person person;
	static boolean gotCorrect;
	
	public static void main(String[] args) {
		int numOfPerson=0;
		String firstname,lastname,phoneNumber,emailAddress,rankOfFaculty="",street,city,state,statusOfStudent="",status;
		int houseNumber=0,zipCode=0;
		int year=0,month=0,day=0;
		//number of person
		while(!gotCorrect){
		try {
		numOfPerson=Integer.parseInt(JOptionPane.showInputDialog(null," Enter number of person,example,enter a value of 2"));
		break;
		}catch (Exception ex) {
			JOptionPane.showMessageDialog(null," Invalid input ");	
			continue;
		}
			}
		
		personArray = new Person[numOfPerson];
		
		for(int i=0;i<numOfPerson;i++) {
		//Student or Faculty		
		boolean statusInBoolean;
		do {
		status=JOptionPane.showInputDialog(null,"Is the "+(i+1)+" person student or faculty?\nExample, enter 's' for student or 'f' for faculty");
		if (status.equals("s")||status.equals("f")) {
			statusInBoolean=false;
			if(status.equals("s")) {
				statusOfStudent=JOptionPane.showInputDialog(null,"What is the status of the "+(i+1)+" Student?");
			}else if(status.equals("f")) {
				rankOfFaculty=JOptionPane.showInputDialog(null,"What is the rank of the "+(i+1)+" faculty?");
				year=Integer.parseInt(JOptionPane.showInputDialog(null," Which year was the "+(i+1)+" faculty appointed?"));
				month=Integer.parseInt(JOptionPane.showInputDialog(null," Which month was the "+(i+1)+" faculty appointed?"));
				day=Integer.parseInt(JOptionPane.showInputDialog(null," Which day was the "+(i+1)+" faculty appointed?"));
			}
		}else {
			statusInBoolean=true;
			JOptionPane.showMessageDialog(null,"Invalid input.\nValid Example, enter 's' for student or 'f' for faculty");
				}
			}while(statusInBoolean);
		MyDate date = new MyDate(year,month,day);
		//individual information
		
		firstname=JOptionPane.showInputDialog(null," Please enter the First Name of the "+(i+1)+" person");
		lastname=JOptionPane.showInputDialog(null," Please enter the Last Name of the "+(i+1)+" person");
		phoneNumber=JOptionPane.showInputDialog(null," Please enter the phone number of the "+(i+1)+" person");
		emailAddress=JOptionPane.showInputDialog(null," Please enter the email address of the "+(i+1)+" person");

		// address information
		street=JOptionPane.showInputDialog(null," What is the street address of the "+(i+1)+" person?");
		
		while(!gotCorrect){
			try {
		houseNumber=Integer.parseInt(JOptionPane.showInputDialog(null," What is the house number of the "+(i+1)+" person?"));
			break;
		}catch (Exception ex) {
			JOptionPane.showMessageDialog(null," Invalid input ");	
			continue;
		}
		}
		
		city=JOptionPane.showInputDialog(null," Which city does the "+(i+1)+" person live in?");
		state=JOptionPane.showInputDialog(null," Which State does the "+(i+1)+" person live in?");
		
		while(!gotCorrect){
			try {
		zipCode=Integer.parseInt(JOptionPane.showInputDialog(null," What is the zipcode of the "+(i+1)+" person?"));
		break;
		}catch (Exception ex) {
			JOptionPane.showMessageDialog(null," Invalid input ");	
			continue;
		}
			}
		
		Address address=new Address(street,houseNumber,city,state,zipCode);
		
		if(status.equals("s")) {
			 person = new Student(firstname,lastname,address,phoneNumber,emailAddress,statusOfStudent);
		}else if(status.equals("f")) {
			 person =new Faculty(firstname,lastname,address,phoneNumber,emailAddress,rankOfFaculty,date);
		}
		personArray [i] = person;
								}
		
		displayStat(personArray);	
		
	}
	
	// display
	public static void displayStat(Person[] personArray){
		String output="";
		for (int i=0;i<personArray.length;i++) {
			output+=personArray[i]+"\n";
		}
		JOptionPane.showMessageDialog(null,output.toString());
	}
}
